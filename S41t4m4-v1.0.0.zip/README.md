# S41t4m4 (v1.0.0)

App Android nativa (Kotlin, senza Compose e senza Google Play Services): apre il **sito che inserisci tu** in una **WebView a schermo intero** con blocco pubblicità. Funziona su smartphone, tablet, Android TV e Fire TV (touch + D-Pad).

Package: `com.s41t4m4.app` · minSdk 21 · targetSdk 34 · tema scuro giallo / rosso / nero.

## Come si usa
- **Primo avvio:** compare il dialog "Benvenuto in S41t4m4. Inserisci l'URL del sito che vuoi aprire." Se manca `http://` o `https://`, viene aggiunto `https://` in automatico. L'URL è salvato in `SharedPreferences` (chiave `target_url`) e caricato subito.
- Avvii successivi: il sito si apre direttamente (o l'ultima pagina visitata, se "Riprendi dall'ultima pagina" è attivo).
- Schermata principale: solo la pagina e l'ingranaggio in alto a destra (si nasconde scrollando in basso e in fullscreen).
- **Menu** del telecomando: alterna lo zoom video Adatta / Riempi.
- **Indietro**: esce dal fullscreen, poi torna indietro nella pagina, poi doppia pressione per uscire.
- **Errore di caricamento** (rete assente, HTTP 404/410, timeout di 30 s): schermata di errore con "Riprova" e "Apri Impostazioni". Non esiste nessun sito di ripiego.

## Impostazioni
| Categoria | Voci |
|---|---|
| GENERALE | URL Sito Web, Ricarica automatica, Riprendi dall'ultima pagina, Cursore virtuale |
| VIDEO | Modalità predefinita (Adatta/Riempi), Fix Video TV |
| RETE | Blocco Pubblicità, User Agent (Auto/TV/Mobile/Desktop), Liste anti-pubblicità |
| MANUTENZIONE | Cancella Cache e Cookie, Info App |

Salvando un nuovo URL (con la verifica HEAD) la WebView si ricarica subito. Cambiando sito, l'ultima pagina visitata del sito precedente viene dimenticata.

User Agent, Cursore e Fix Video TV sono **Auto** per default: su TV/Fire TV diventano TV / attivo / attivo, su smartphone e tablet Mobile / disattivo / disattivo. Si possono forzare dalle impostazioni.

## Tema
| Ruolo | Colore |
|---|---|
| Primario (accenti, barra di caricamento, focus D-Pad, switch) | Giallo `#FFD700` |
| Secondario (pulsanti principali, pressione) | Rosso `#E53935` |
| Sfondo (splash, impostazioni, errore) | Grigio scuro `#121212` |

Icone adaptive: sfondo giallo + Saitama in primo piano. Banner TV 320x180 e splash dal logo.

## Zoom video (solo JavaScript)
`assets/video_fit.js` applica `transform: scale()` solo al tag `<video>`, con un limite massimo (`capScale`: 4:3 max 1.3x, 16:9 max 2x). I controlli del player non vengono toccati. Negli iframe di altri domini serve una WebView che supporti gli script a inizio documento (Info App → "script in tutti i frame"). Se il player disegna il video su canvas o nativamente, lo zoom non ha effetto.

## Blocco pubblicità
Motore nativo senza librerie: lista offline (`assets/ad_hosts.txt`), liste scaricate ogni 7 giorni (EasyList, AdGuard Base, Peter Lowe), whitelist per CDN e player (`assets/ad_whitelist.txt`), popup sempre bloccati (`onCreateWindow` restituisce `false`), pulizia dei banner via JS. Log: `adb logcat -s S41t4m4Ads`.

## Crash
Un eventuale crash viene registrato (Logcat `S41t4m4_Crash` e Info App → "Ultimo errore").

## Compilazione con GitHub Actions
Carica il progetto in un nuovo repository (ramo `main`), poi *Actions → Build S41t4m4 APK → Run workflow* e scarica l'artefatto `s41t4m4-debug-apk`. Requisiti: JDK 17, Gradle 8.7, AGP 8.3.2, Kotlin 1.9.23 (già nel workflow). L'`applicationId` è `com.s41t4m4.app`.
