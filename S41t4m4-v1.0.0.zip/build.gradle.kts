// Build root: dichiara solo i plugin (versioni compatibili con Gradle 8.7 e JDK 17)
plugins {
    id("com.android.application") version "8.3.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.23" apply false
}
