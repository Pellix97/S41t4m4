/* S41t4m4 - zoom video in JavaScript puro (ispirato a FillScreenAnywhere).

   Script autonomo e idempotente: si installa una sola volta per frame (window.__h1ZoomInstalled)
   ed espone  window.__h1Zoom(mode)   mode: 0 = Adatta (nessuno zoom), 1 = Riempi.

   Regole per non rompere il player:
   - transform: scale() SOLO sul tag <video>. Mai sulla pagina, mai sui controlli (sono elementi separati:
     restano della loro dimensione e cliccabili). Nessuna modifica a z-index o pointer-events.
   - il wrapper del video riceve soltanto overflow:hidden (ritaglia l'eccesso della scala);
   - gli stili originali (transform, transform-origin, overflow) vengono salvati e ripristinati con Adatta;
   - se il sito riempie gia' con object-fit cover/fill non si fa nulla.

   Gira in ogni frame (anche iframe di altri domini, se la WebView supporta gli script a inizio documento):
   il frame genitore inoltra la modalita' ai figli con postMessage. */
(function () {
  if (window.__h1ZoomInstalled) { return; }
  window.__h1ZoomInstalled = true;

  var MODE = 0;            /* 0 = Adatta, 1 = Riempi */
  var observer = null;
  var timer = null;

  /* Limita lo zoom massimo: un 4:3 (o piu' stretto) non va ingrandito oltre ~1.3x (taglierebbe le teste);
     un 16:9 o piu' largo puo' ingrandirsi di piu' per togliere le bande nere. */
  function capScale(scale, videoRatio, screenRatio) {
    var cap;
    if (videoRatio <= 1.45) { cap = 1.3; }          /* 4:3 o piu' stretto */
    else if (videoRatio < 1.7) { cap = 1.5; }       /* formati intermedi (3:2, 14:9...) */
    else { cap = 2.0; }                             /* 16:9 e piu' larghi */
    return Math.max(1, Math.min(scale, cap));
  }

  /* Scala uniforme per riempire l'area: max(video/schermo, schermo/video), poi limitata da capScale. */
  function computeScale(videoRatio, screenRatio) {
    if (!(videoRatio > 0) || !(screenRatio > 0)) { return 1; }
    var scale = Math.max(videoRatio / screenRatio, screenRatio / videoRatio);
    return capScale(scale, videoRatio, screenRatio);
  }

  function setProp(style, name, value, priority) {
    if (value) { style.setProperty(name, value, priority || ''); } else { style.removeProperty(name); }
  }

  /* Wrapper del video: l'antenato piu' alto (max 4 livelli) che lo avvolge strettamente. */
  function findWrapper(v) {
    var best = v.parentElement;
    var vw = Math.max(v.clientWidth, 1), vh = Math.max(v.clientHeight, 1);
    var el = v.parentElement;
    var steps = 0;
    while (el && el.tagName !== 'BODY' && el.tagName !== 'HTML' && steps < 4) {
      if (el.clientWidth > vw * 1.25 + 20 || el.clientHeight > vh * 1.25 + 20) { break; }
      best = el;
      el = el.parentElement;
      steps++;
    }
    return best;
  }

  /* Ripristina gli stili originali del sito. */
  function restore(v) {
    var o = v.__h1;
    if (!o) { return; }
    setProp(v.style, 'transform', o.transform, o.transformPrio);
    setProp(v.style, 'transform-origin', o.origin, o.originPrio);
    if (o.wrapper) { setProp(o.wrapper.style, 'overflow', o.overflow, o.overflowPrio); }
    v.__h1 = null;
  }

  function applyTo(v) {
    var win = v.ownerDocument.defaultView || window;
    if (MODE === 0) { restore(v); return; }
    if (!v.videoWidth || !v.videoHeight) { return; }          /* metadati non ancora pronti */
    var cs = win.getComputedStyle(v);
    if (cs.objectFit === 'cover' || cs.objectFit === 'fill') { restore(v); return; }
    var w = v.clientWidth, h = v.clientHeight;
    if (w < 50 || h < 50) { restore(v); return; }
    var scale = computeScale(v.videoWidth / v.videoHeight, w / h);   /* a schermo intero l'area e' lo schermo */
    if (Math.abs(scale - 1) < 0.01) { restore(v); return; }

    var o = v.__h1;
    if (!o) {
      var base = (cs.transform && cs.transform !== 'none') ? cs.transform : '';
      var wrap = findWrapper(v);
      o = v.__h1 = {
        transform: v.style.getPropertyValue('transform'), transformPrio: v.style.getPropertyPriority('transform'),
        origin: v.style.getPropertyValue('transform-origin'), originPrio: v.style.getPropertyPriority('transform-origin'),
        base: base, wrapper: wrap,
        overflow: wrap ? wrap.style.getPropertyValue('overflow') : '',
        overflowPrio: wrap ? wrap.style.getPropertyPriority('overflow') : ''
      };
    }
    /* se il sito ha gia' un transform sul video lo si compone con la scala */
    v.style.setProperty('transform', (o.base ? o.base + ' ' : '') + 'scale(' + scale + ')', 'important');
    if (!o.base) { v.style.setProperty('transform-origin', 'center center', 'important'); }
    if (o.wrapper) { o.wrapper.style.setProperty('overflow', 'hidden', 'important'); }
  }

  function schedule() {
    if (MODE === 0 || timer) { return; }
    timer = setTimeout(function () { timer = null; scan(document); }, 120);
  }

  function watch(v) {
    if (v.__h1w) { return; }
    v.__h1w = true;
    var again = function () { applyTo(v); };
    v.addEventListener('loadedmetadata', again);
    v.addEventListener('resize', again);
    v.addEventListener('emptied', again);
    if (window.ResizeObserver) { try { new ResizeObserver(schedule).observe(v); } catch (e) {} }
  }

  /* Applica la modalita' ai video del documento, agli iframe dello stesso dominio e (postMessage) agli altri. */
  function scan(doc) {
    var count = 0;
    var vids = doc.getElementsByTagName('video');
    for (var i = 0; i < vids.length; i++) { watch(vids[i]); applyTo(vids[i]); count++; }
    var fr = doc.getElementsByTagName('iframe');
    for (var j = 0; j < fr.length; j++) {
      var f = fr[j];
      if (!f.__h1ld) {
        f.__h1ld = true;
        f.addEventListener('load', function () {
          try { this.contentWindow.postMessage({ __h1zoom: MODE }, '*'); } catch (e) {}
        });
      }
      try {
        var d = f.contentDocument;                                   /* stesso dominio */
        if (d && d.documentElement && !(d.defaultView && d.defaultView.__h1ZoomInstalled)) { count += scan(d); }
      } catch (e2) {}
      try { f.contentWindow.postMessage({ __h1zoom: MODE }, '*'); } catch (e3) {}
    }
    return count;
  }

  function startObserver() {
    if (observer || !window.MutationObserver || !document.documentElement) { return; }
    observer = new MutationObserver(schedule);
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function stopObserver() {
    if (observer) { observer.disconnect(); observer = null; }
  }

  function setMode(mode) {
    MODE = (mode === 1) ? 1 : 0;
    var n = scan(document);
    if (MODE !== 0) { startObserver(); } else { stopObserver(); }
    return n;
  }

  window.addEventListener('message', function (e) {
    var d = e.data;
    if (e.source === window.parent && d && typeof d === 'object' && typeof d.__h1zoom === 'number') {
      setMode(d.__h1zoom);
    }
  });
  window.addEventListener('resize', schedule);
  document.addEventListener('fullscreenchange', schedule);
  document.addEventListener('webkitfullscreenchange', schedule);

  window.__h1Zoom = function (mode) { return setMode(mode | 0); };
  window.__h1Zoom.compute = computeScale;
})();
