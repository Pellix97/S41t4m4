package com.s41t4m4.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.animation.LinearInterpolator
import android.webkit.WebView
import android.widget.FrameLayout
import kotlin.math.abs

/**
 * FrameLayout con cursore virtuale per D-Pad (TV / Firestick).
 *  - Aspetto: cerchio bianco con bordo nero 2dp, punto centrale nero, 24dp, alpha 200, ombra.
 *  - Movimento: 30dp per pressione, x2.5 dopo 500ms di pressione continua, interpolazione lineare 200ms.
 *  - Auto-hide: 4s, fade-out 500ms, fade-in 200ms; non si nasconde sopra un elemento interattivo.
 *  - Click (OK): effetto pulse 1.0 -> 1.3 -> 1.0 in 150ms; focus alla WebView sui campi di testo.
 */
class CursorLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /** WebView controllata dal cursore (scroll ai bordi, hit test, focus). */
    var webView: WebView? = null

    /** False sugli smartphone (si usa il touch): il layout non intercetta più il D-Pad. */
    var cursorEnabled: Boolean = true

    private val d = resources.displayMetrics.density
    private val stepPx = 30f * d
    private val radius = 12f * d          // diametro 24dp
    private val border = 2f * d
    private val edge = 40f * d

    private var cx = 0f
    private var cy = 0f
    private var tx = 0f
    private var ty = 0f
    private var initialized = false
    private var cursorAlpha = 0f
    private var pulseScale = 1f

    private var moveAnim: ValueAnimator? = null
    private var alphaAnim: ValueAnimator? = null
    private var pulseAnim: ValueAnimator? = null

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFD700"); style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = border
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.FILL }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.FILL }

    private val hideRunnable = object : Runnable {
        override fun run() {
            // Non nascondere se il cursore è fermo su un elemento interattivo
            if (isInteractive(probeHitType())) {
                postDelayed(this, 4000)
            } else {
                animateAlpha(0f, 500)
            }
        }
    }

    init { setWillNotDraw(false) }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!initialized) {
            cx = w / 2f; cy = h / 2f; tx = cx; ty = cy
            initialized = true
        }
        cx = cx.coerceIn(0f, w.toFloat()); cy = cy.coerceIn(0f, h.toFloat())
        tx = tx.coerceIn(0f, w.toFloat()); ty = ty.coerceIn(0f, h.toFloat())
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!cursorEnabled) return super.dispatchKeyEvent(event)
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (event.action == KeyEvent.ACTION_DOWN) move(event)
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (cursorAlpha >= 0.05f) {
                    if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) clickAtCursor()
                    return true
                } else if (event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {
                    // Cursore nascosto: il primo OK lo fa riapparire senza cliccare
                    if (event.action == KeyEvent.ACTION_DOWN) showCursor()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun move(event: KeyEvent) {
        val mult = if (event.eventTime - event.downTime > 500) 2.5f else 1f
        val step = stepPx * mult
        var dx = 0f
        var dy = 0f
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> dx = -step
            KeyEvent.KEYCODE_DPAD_RIGHT -> dx = step
            KeyEvent.KEYCODE_DPAD_UP -> dy = -step
            KeyEvent.KEYCODE_DPAD_DOWN -> dy = step
        }
        // Scroll della pagina solo in verticale quando il cursore è ai bordi alto/basso
        // (niente scroll orizzontale: su TV faceva scorrere la pagina di lato)
        val wv = webView
        if (wv != null) {
            if (dy < 0 && ty <= edge) wv.scrollBy(0, dy.toInt())
            if (dy > 0 && ty >= height - edge) wv.scrollBy(0, dy.toInt())
        }
        tx = (tx + dx).coerceIn(0f, width.toFloat())
        ty = (ty + dy).coerceIn(0f, height.toFloat())
        animateMove()
        showCursor()
    }

    private fun animateMove() {
        moveAnim?.cancel()
        val sx = cx
        val sy = cy
        moveAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 200
            interpolator = LinearInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                cx = sx + (tx - sx) * f
                cy = sy + (ty - sy) * f
                invalidate()
            }
            start()
        }
    }

    private fun showCursor() {
        removeCallbacks(hideRunnable)
        if (cursorAlpha < 1f) animateAlpha(1f, 200)
        postDelayed(hideRunnable, 4000)
    }

    private fun animateAlpha(target: Float, durationMs: Long) {
        alphaAnim?.cancel()
        val delta = abs(target - cursorAlpha)
        if (delta < 0.01f) { cursorAlpha = target; invalidate(); return }
        alphaAnim = ValueAnimator.ofFloat(cursorAlpha, target).apply {
            duration = (durationMs * delta).toLong().coerceAtLeast(1L)
            addUpdateListener { cursorAlpha = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun pulse() {
        pulseAnim?.cancel()
        pulseAnim = ValueAnimator.ofFloat(1f, 1.3f, 1f).apply {
            duration = 150
            addUpdateListener { pulseScale = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    /**
     * Invia un DOWN+CANCEL alla WebView nel punto del cursore per aggiornare hitTestResult
     * (il click vero non parte). Approssimazione: il risultato può arrivare con un attimo di ritardo.
     */
    private fun probeHitType(): Int {
        val wv = webView ?: return WebView.HitTestResult.UNKNOWN_TYPE
        if (wv.visibility != VISIBLE || wv.width == 0) return WebView.HitTestResult.UNKNOWN_TYPE
        val t = SystemClock.uptimeMillis()
        val x = cx - wv.left
        val y = cy - wv.top
        val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0)
        val cancel = MotionEvent.obtain(t, t + 1, MotionEvent.ACTION_CANCEL, x, y, 0)
        wv.dispatchTouchEvent(down)
        wv.dispatchTouchEvent(cancel)
        down.recycle(); cancel.recycle()
        return wv.hitTestResult?.type ?: WebView.HitTestResult.UNKNOWN_TYPE
    }

    private fun isInteractive(type: Int): Boolean =
        type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
            type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE ||
            type == WebView.HitTestResult.EDIT_TEXT_TYPE ||
            type == WebView.HitTestResult.PHONE_TYPE ||
            type == WebView.HitTestResult.EMAIL_TYPE ||
            type == WebView.HitTestResult.GEO_TYPE

    private fun clickAtCursor() {
        // Su un campo di testo: sposta il focus sulla WebView prima del click (fa apparire la tastiera)
        if (probeHitType() == WebView.HitTestResult.EDIT_TEXT_TYPE) webView?.requestFocus()
        pulse()
        showCursor()
        val t = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, cx, cy, 0)
        val up = MotionEvent.obtain(t, t + 60, MotionEvent.ACTION_UP, cx, cy, 0)
        dispatchTouchEvent(down)
        dispatchTouchEvent(up)
        down.recycle(); up.recycle()
    }

    // Disegna il cursore sopra ai figli (WebView compresa)
    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        val a = cursorAlpha
        if (a <= 0.01f) return
        val r = radius * pulseScale
        // Ombra: cerchi neri traslucidi sfalsati verso il basso
        shadowPaint.alpha = (50 * a).toInt()
        canvas.drawCircle(cx, cy + 3f * d, r + 3f * d, shadowPaint)
        shadowPaint.alpha = (70 * a).toInt()
        canvas.drawCircle(cx, cy + 2f * d, r + 1.5f * d, shadowPaint)
        // Cerchio esterno bianco con bordo nero (opacità 200)
        fillPaint.alpha = (200 * a).toInt()
        canvas.drawCircle(cx, cy, r - border, fillPaint)
        strokePaint.alpha = (200 * a).toInt()
        canvas.drawCircle(cx, cy, r - border / 2f, strokePaint)
        // Punto centrale nero
        dotPaint.alpha = (200 * a).toInt()
        canvas.drawCircle(cx, cy, r * 0.28f, dotPaint)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(hideRunnable)
        moveAnim?.cancel(); alphaAnim?.cancel(); pulseAnim?.cancel()
        super.onDetachedFromWindow()
    }
}
