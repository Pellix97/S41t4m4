package com.s41t4m4.app

import android.app.Application
import android.util.Log

/**
 * Application: inizializza il blocco pubblicità, aggiorna le liste se più vecchie di 7 giorni
 * e registra l'ultimo crash (visibile nelle impostazioni e su Logcat, tag "S41t4m4_Crash").
 */
class S41t4m4App : Application() {
    override fun onCreate() {
        super.onCreate()
        installCrashLogger()
        Prefs.migrate(this)
        DeviceConfig.ensureFirstRun(this)
        AdBlocker.init(this)
        AdBlocker.enabled = Prefs.get(this).getBoolean(Prefs.KEY_ADBLOCK, true)
        AdBlocker.updateIfStale(this)
    }

    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                Log.e("S41t4m4_Crash", "Eccezione non gestita nel thread ${thread.name}", error)
                Prefs.get(this).edit()
                    .putString(Prefs.KEY_LAST_CRASH, Log.getStackTraceString(error).take(1500))
                    .putLong(Prefs.KEY_LAST_CRASH_TS, System.currentTimeMillis())
                    .commit()
            } catch (ignored: Throwable) {
                // il logger non deve mai causare un secondo crash
            }
            previous?.uncaughtException(thread, error)
        }
    }
}
