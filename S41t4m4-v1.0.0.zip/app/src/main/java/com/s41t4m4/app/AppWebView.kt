package com.s41t4m4.app

import android.content.Context
import android.util.AttributeSet
import android.webkit.WebView

/** WebView che notifica lo scroll (serve all'auto-hide dell'ingranaggio). Compatibile con tutte le versioni di Android. */
class AppWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : WebView(context, attrs) {

    /** Chiamato a ogni scroll: (posizione verticale, variazione rispetto a prima). */
    var onScrolled: ((top: Int, delta: Int) -> Unit)? = null

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrolled?.invoke(t, t - oldt)
    }
}
