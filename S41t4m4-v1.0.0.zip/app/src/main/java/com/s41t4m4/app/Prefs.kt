package com.s41t4m4.app

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri

/** Chiavi e helper per le preferenze dell'app. */
object Prefs {
    const val FILE = "s41t4m4_prefs"

    // Sito
    const val KEY_TARGET = "target_url"               // URL del sito da aprire (inserito dall'utente)
    const val KEY_RELOAD_MIN = "reload_minutes"
    const val KEY_RESUME = "resume_last"              // Riprendi dall'ultima pagina (default: attivo)
    const val KEY_LAST_VISITED = "last_visited_url"
    const val KEY_LAST_VISITED_TS = "last_visited_ts"

    // Richieste dalle impostazioni alla schermata principale
    const val KEY_RELOAD_REQ = "reload_requested"
    const val KEY_CLEAR_REQ = "clear_data_requested"

    // DeviceConfig: 0 = Auto (segue il dispositivo), 1 = attivo / TV, 2 = disattivo / Mobile, 3 = Desktop (solo User Agent)
    const val KEY_UA_MODE = "ua_mode"
    const val KEY_VIDEO_FIX = "video_fix"
    const val KEY_CURSOR = "cursor_mode"
    const val KEY_PROFILE = "device_profile"          // profilo rilevato al primo avvio
    const val KEY_TV_MODE = "tv_mode"                 // vecchia chiave (<= 1.4.1): solo per la migrazione

    // Video e rete
    const val KEY_ZOOM = "zoom_mode"                  // 0 = Adatta, 1 = Riempi
    const val KEY_ZOOM_ALLFRAMES = "zoom_allframes"   // true se lo script zoom gira anche negli iframe
    const val KEY_ADBLOCK = "adblock_enabled"         // default: attivo

    // Diagnostica
    const val KEY_LAST_CRASH = "last_crash"
    const val KEY_LAST_CRASH_TS = "last_crash_ts"

    fun get(ctx: Context): SharedPreferences = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** URL salvato dall'utente, oppure null se manca (primo avvio) o non è un indirizzo http(s). */
    fun targetUrl(p: SharedPreferences): String? =
        p.getString(KEY_TARGET, null)?.takeIf { it.startsWith("http://") || it.startsWith("https://") }

    /**
     * Normalizza l'indirizzo digitato: aggiunge "https://" se manca lo schema, rifiuta spazi, schemi diversi da
     * http/https e indirizzi senza host. Restituisce null se non valido.
     */
    fun normalizeUrl(raw: String): String? {
        val t = raw.trim()
        if (t.isEmpty() || t.any { it.isWhitespace() }) return null
        val lower = t.lowercase()
        val url = when {
            lower.startsWith("http://") || lower.startsWith("https://") -> t
            t.contains("://") -> return null
            else -> "https://$t"
        }
        val host = Uri.parse(url).host
        return if (host.isNullOrBlank()) null else url
    }

    /** Modalità zoom: 1 = Riempi, qualunque altro valore (anche il vecchio "Stira") = Adatta. */
    fun zoomMode(ctx: Context): Int = if (get(ctx).getInt(KEY_ZOOM, 0) == 1) 1 else 0

    /** Migra la vecchia "Modalità TV" (1.3.2 - 1.4.1) sulle tre voci di DeviceConfig. */
    fun migrate(ctx: Context) {
        val p = get(ctx)
        if (p.contains(KEY_TV_MODE) && !p.contains(KEY_UA_MODE)) {
            val m = p.getInt(KEY_TV_MODE, 0)
            p.edit()
                .putInt(KEY_UA_MODE, m)
                .putInt(KEY_VIDEO_FIX, m)
                .putInt(KEY_CURSOR, m)
                .remove(KEY_TV_MODE)
                .apply()
        }
    }
}
