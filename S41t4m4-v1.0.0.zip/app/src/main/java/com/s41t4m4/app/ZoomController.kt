package com.s41t4m4.app

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.util.Log
import android.webkit.WebView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/**
 * Gestione dello zoom video, SOLO JavaScript (assets/video_fit.js).
 *
 *  - install(): registra lo script a inizio documento in tutti i frame (iframe inclusi) se la WebView lo supporta;
 *    altrimenti apply() lo inietta con evaluateJavascript (lo script è idempotente).
 *  - lo script scala solo il tag <video>: i controlli del player non vengono toccati.
 */
class ZoomController(private val context: Context, private val webView: WebView) {

    private val prefs = Prefs.get(context)

    private val script: String by lazy {
        try {
            context.assets.open("video_fit.js").bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            Log.e(TAG, "video_fit.js non leggibile", e)
            ""
        }
    }

    /** Registra lo script come "document start script" in tutti i frame. Restituisce true se la WebView lo supporta. */
    @SuppressLint("RequiresFeature")
    fun install(): Boolean {
        var allFrames = false
        if (script.isNotEmpty()) {
            try {
                if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    WebViewCompat.addDocumentStartJavaScript(webView, script, setOf("*"))
                    allFrames = true
                }
            } catch (e: Throwable) {
                Log.w(TAG, "Script zoom a inizio documento non disponibile", e)
            }
        }
        prefs.edit().putBoolean(Prefs.KEY_ZOOM_ALLFRAMES, allFrames).apply()
        return allFrames
    }

    fun mode(): Int = Prefs.zoomMode(context)

    /** Applica la modalità corrente (0 = Adatta toglie lo zoom). */
    fun apply() {
        if (script.isEmpty()) return
        webView.evaluateJavascript("$script\n;window.__h1Zoom(${mode()});", null)
    }

    /** Alterna Adatta <-> Riempi, lo salva come modalità predefinita e lo applica. Restituisce la nuova modalità. */
    fun toggle(): Int {
        val next = if (mode() == 1) 0 else 1
        prefs.edit().putInt(Prefs.KEY_ZOOM, next).apply()
        apply()
        return next
    }

    /** All'ingresso in fullscreen riapplica subito e dopo 0,3 / 1 / 2,5 s: i player cambiano dimensione in ritardo. */
    fun burst(handler: Handler, stillActive: () -> Boolean) {
        if (mode() == 0) return
        apply()
        for (delay in longArrayOf(300L, 1000L, 2500L)) {
            handler.postDelayed({ if (stillActive()) apply() }, delay)
        }
    }

    /** True se nella pagina c'è un video (o un iframe grande che può contenerlo). */
    fun probeVideo(callback: (Boolean) -> Unit) {
        webView.evaluateJavascript(PROBE_JS) { res ->
            callback((res?.trim()?.toIntOrNull() ?: 0) > 0)
        }
    }

    private companion object {
        const val TAG = "S41t4m4Zoom"
        const val PROBE_JS =
            "(function(){var n=document.getElementsByTagName('video').length;" +
                "var f=document.getElementsByTagName('iframe');" +
                "for(var i=0;i<f.length;i++){if(f[i].offsetWidth>=200&&f[i].offsetHeight>=100)n++;}return n;})()"
    }
}
