package com.s41t4m4.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Schermata principale: SOLO la WebView a schermo intero, con l'ingranaggio (auto-hide) e una sottile
 * barra di caricamento. Splash con fade-in, schermata di errore, fullscreen video, cronologia intelligente.
 * L'URL del sito lo inserisce l'utente (primo avvio: dialog di benvenuto); nessuna pagina indice.
 */
class MainActivity : Activity() {

    private companion object {
        const val TAG = "S41t4m4"
        const val SPLASH_MIN_MS = 1800L
        const val BACK_EXIT_WINDOW_MS = 2000L
        const val SAVED_LOAD_TIMEOUT_MS = 7000L
        const val TARGET_LOAD_TIMEOUT_MS = 30_000L
        const val TIMEOUT_MIN_PROGRESS = 60        // oltre questa percentuale la pagina è considerata in arrivo
        const val GEAR_ALPHA = 0.7f
        const val FULLSCREEN_BACK_GUARD_MS = 600L
    }

    private lateinit var webView: AppWebView
    private lateinit var cursorLayout: CursorLayout
    private lateinit var btnSettings: ImageButton
    private lateinit var progress: ProgressBar
    private lateinit var errorView: LinearLayout
    private lateinit var errorDetail: TextView
    private lateinit var btnRetry: Button
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var splash: View
    private lateinit var splashLogo: ImageView
    private lateinit var zoom: ZoomController

    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { Prefs.get(this) }
    private var setupDialog: AlertDialog? = null

    // Pagina e fullscreen
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var pageHost: String? = null
    private var pageLoaded = false

    // Splash
    private var splashMinDone = false
    private var contentReady = false
    private var splashGone = false

    // Cronologia intelligente
    private var loadingSaved = false

    // Interfaccia
    private var gearVisible = true
    private var lastSettingsOpen = 0L
    private var lastBackAt = 0L
    private var lastFullscreenExitAt = 0L          // quando si è appena usciti dal fullscreen
    private var backStartedInFullscreen = false    // il Back in corso è iniziato in fullscreen

    private val autoReloadRunnable = object : Runnable {
        override fun run() {
            if (customView == null && errorView.visibility != View.VISIBLE) loadTarget()
            scheduleAutoReload()
        }
    }

    // Se l'ultimo link salvato non finisce di caricare entro 7 secondi
    private val savedTimeout = Runnable { expireSavedLink() }

    // Se il sito inserito dall'utente non finisce di caricare: schermata di errore (nessun fallback)
    private val targetTimeout = Runnable {
        if (!pageLoaded && customView == null && webView.progress < TIMEOUT_MIN_PROGRESS) {
            webView.stopLoading()
            showError(getString(R.string.load_timeout))
        }
    }

    // ---------------------------------------------------------------- ciclo di vita

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        cursorLayout = findViewById(R.id.cursorLayout)
        btnSettings = findViewById(R.id.btnSettings)
        progress = findViewById(R.id.progress)
        errorView = findViewById(R.id.errorView)
        errorDetail = findViewById(R.id.errorDetail)
        btnRetry = findViewById(R.id.btnRetry)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        splash = findViewById(R.id.splash)
        splashLogo = findViewById(R.id.splashLogo)
        cursorLayout.webView = webView
        zoom = ZoomController(this, webView)

        btnSettings.setOnClickListener { openSettings() }
        btnRetry.setOnClickListener { loadTarget() }
        findViewById<Button>(R.id.btnErrSettings).setOnClickListener { openSettings() }

        webView.onScrolled = { top, delta -> onPageScrolled(top, delta) }

        setupWebView()
        enterImmersive()
        // La pagina deve sempre partire in modalità normale: nessuno stato fullscreen di sessioni precedenti
        resetFullscreenState()

        if (savedInstanceState != null) {
            splash.visibility = View.GONE
            splashMinDone = true; contentReady = true; splashGone = true
            webView.restoreState(savedInstanceState)
            if (Prefs.targetUrl(prefs) == null) showSetupDialog()
        } else {
            startSplash()
            startInitialLoad()
        }
    }

    override fun onResume() {
        super.onResume()
        // Stato fullscreen incoerente (vista video morta, container visibile senza video...): ripristina la modalità normale
        val inconsistent = (customView != null) != (fullscreenContainer.visibility == View.VISIBLE) ||
            (customView != null && fullscreenContainer.childCount == 0)
        if (inconsistent) resetFullscreenState()
        webView.onResume()
        // Anti-screensaver / Ambient Mode: schermo sempre acceso finché l'app è in primo piano
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()
        // Le impostazioni potrebbero essere cambiate (User Agent, cursore, Blocco Pubblicità, zoom)
        applyConfig()
        when {
            prefs.getBoolean(Prefs.KEY_CLEAR_REQ, false) -> {
                prefs.edit().putBoolean(Prefs.KEY_CLEAR_REQ, false).apply()
                clearBrowsingData()
            }
            prefs.getBoolean(Prefs.KEY_RELOAD_REQ, false) -> {
                prefs.edit().putBoolean(Prefs.KEY_RELOAD_REQ, false).apply()
                loadTarget()
            }
        }
        zoom.apply()
        scheduleAutoReload()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(autoReloadRunnable)
        // Schermo non più forzato acceso quando l'app non è in primo piano
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // Cronologia intelligente: salva URL corrente e timestamp
        val url: String? = webView.url
        if (!url.isNullOrBlank() && (url.startsWith("http://") || url.startsWith("https://"))) {
            prefs.edit()
                .putString(Prefs.KEY_LAST_VISITED, url)
                .putLong(Prefs.KEY_LAST_VISITED_TS, System.currentTimeMillis())
                .apply()
        }
        if (customView == null) webView.onPause()
    }

    override fun onStop() {
        super.onStop()
        // App non più visibile durante un video a schermo intero: esci dal fullscreen e ferma l'audio.
        // Altrimenti al ritorno resterebbe una vista video "fantasma".
        if (customView != null) {
            resetFullscreenState()
            pauseVideos()
            webView.onPause()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        setupDialog?.dismiss()
        webView.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- splash

    /** Logo con fade-in elegante (alpha + leggera scala). */
    private fun startSplash() {
        splash.alpha = 0f
        splashLogo.scaleX = 0.92f
        splashLogo.scaleY = 0.92f
        splash.animate().alpha(1f).setDuration(900).setInterpolator(DecelerateInterpolator()).start()
        splashLogo.animate().scaleX(1f).scaleY(1f).setDuration(1400).setInterpolator(DecelerateInterpolator()).start()
        ui.postDelayed({ splashMinDone = true; tryHideSplash() }, SPLASH_MIN_MS)
    }

    private fun tryHideSplash() {
        if (splashGone || !splashMinDone || !contentReady) return
        splashGone = true
        splash.animate().alpha(0f).setDuration(450).withEndAction { splash.visibility = View.GONE }.start()
    }

    // ---------------------------------------------------------------- caricamento

    /**
     * Nessun URL salvato (primo avvio): dialog di benvenuto. Altrimenti, se "Riprendi dall'ultima pagina" è attivo e
     * l'ultima pagina esiste la carica subito, altrimenti carica l'URL del sito.
     */
    private fun startInitialLoad() {
        if (Prefs.targetUrl(prefs) == null) {
            showSetupDialog()
            return
        }
        val saved = prefs.getString(Prefs.KEY_LAST_VISITED, null)
        if (prefs.getBoolean(Prefs.KEY_RESUME, true) && !saved.isNullOrBlank()) {
            loadSavedUrl(saved)
        } else {
            loadTarget()
        }
    }

    private fun loadSavedUrl(url: String) {
        loadingSaved = true
        pageLoaded = false
        hideError()
        webView.loadUrl(url)
        ui.removeCallbacks(savedTimeout)
        ui.postDelayed(savedTimeout, SAVED_LOAD_TIMEOUT_MS)
    }

    /** Ultima pagina salvata scaduta (errore, HTTP >= 400 o timeout di 7s): ripiega sull'URL del sito. */
    private fun expireSavedLink() {
        if (!loadingSaved) return
        loadingSaved = false
        ui.removeCallbacks(savedTimeout)
        prefs.edit().remove(Prefs.KEY_LAST_VISITED).apply()
        Toast.makeText(this, R.string.link_expired, Toast.LENGTH_LONG).show()
        webView.stopLoading()
        loadTarget()
    }

    /** Carica l'URL del sito salvato dall'utente. Se manca (primo avvio) mostra il dialog di benvenuto. */
    private fun loadTarget() {
        val url = Prefs.targetUrl(prefs)
        if (url == null) {
            showSetupDialog()
            return
        }
        loadingSaved = false
        ui.removeCallbacks(savedTimeout)
        ui.removeCallbacks(targetTimeout)
        hideError()
        pageLoaded = false
        webView.loadUrl(url)
        ui.postDelayed(targetTimeout, TARGET_LOAD_TIMEOUT_MS)
    }

    // ---------------------------------------------------------------- primo avvio

    /**
     * Dialog di benvenuto (scuro, giallo/rosso): campo URL focalizzabile col D-Pad. "Salva" normalizza l'indirizzo
     * (aggiunge https:// se manca) e lo carica subito; "Esci" chiude l'app. Non si chiude con Back o toccando fuori.
     */
    private fun showSetupDialog() {
        if (setupDialog?.isShowing == true) return
        // La splash non deve restare sopra il dialog
        contentReady = true
        tryHideSplash()

        val density = resources.displayMetrics.density
        val pad = (20 * density).toInt()
        val input = EditText(this).apply {
            hint = getString(R.string.url_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_DONE
            setSingleLine()
            setTextColor(ContextCompat.getColor(context, R.color.text_primary))
            setHintTextColor(ContextCompat.getColor(context, R.color.text_dim))
            setBackgroundResource(R.drawable.bg_focusable)
            setPadding((14 * density).toInt(), (10 * density).toInt(), (14 * density).toInt(), (10 * density).toInt())
        }
        val holder = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT
            ))
        }
        val dialog = AlertDialog.Builder(this, R.style.S41Dialog)
            .setTitle(R.string.welcome_title)
            .setMessage(R.string.welcome_msg)
            .setView(holder)
            .setCancelable(false)
            .setPositiveButton(R.string.btn_save, null)   // il click è gestito sotto, per non chiudere con URL non valido
            .setNegativeButton(R.string.btn_exit, null)
            .create()

        fun submit() {
            val url = Prefs.normalizeUrl(input.text.toString())
            if (url == null) {
                input.error = getString(R.string.url_invalid)
                return
            }
            prefs.edit().putString(Prefs.KEY_TARGET, url).apply()
            dialog.dismiss()
            setupDialog = null
            loadTarget()
        }

        dialog.setOnShowListener {
            dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { submit() }
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener { finish() }
            input.requestFocus()
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { submit(); true } else false
        }
        setupDialog = dialog
        dialog.show()
    }

    private fun scheduleAutoReload() {
        ui.removeCallbacks(autoReloadRunnable)
        val minutes = prefs.getInt(Prefs.KEY_RELOAD_MIN, 0)
        if (minutes > 0) ui.postDelayed(autoReloadRunnable, minutes * 60_000L)
    }

    // ---------------------------------------------------------------- schermata di errore

    private fun showError(detail: String) {
        errorDetail.text = detail
        cursorLayout.visibility = View.GONE
        progress.visibility = View.GONE
        errorView.visibility = View.VISIBLE
        btnRetry.requestFocus()
        contentReady = true
        tryHideSplash()
    }

    private fun hideError() {
        errorView.visibility = View.GONE
        cursorLayout.visibility = View.VISIBLE
    }

    // ---------------------------------------------------------------- WebView

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setBuiltInZoomControls(false)
        s.setDisplayZoomControls(false)
        // true: così ogni window.open()/target=_blank passa da onCreateWindow, che li rifiuta sempre.
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = false
        s.cacheMode = WebSettings.LOAD_DEFAULT
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        webView.setBackgroundColor(0xFF000000.toInt())
        applyConfig()
        zoom.install()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return if (AdBlocker.shouldBlock(request.url, pageHost, request.isForMainFrame))
                    AdBlocker.emptyResponse() else null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme ?: return true
                // Blocca intent:// e altri schemi non web
                if (scheme != "http" && scheme != "https") return true
                // Le regole anti-redirect valgono solo per il frame principale (gli iframe dei player restano liberi)
                if (!request.isForMainFrame) return false
                val gesture = if (Build.VERSION.SDK_INT >= 24) request.hasGesture() else true
                val redirect = if (Build.VERSION.SDK_INT >= 24) request.isRedirect else false
                return AdBlocker.shouldBlockNavigation(request.url.host, pageHost, gesture, redirect, pageLoaded)
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                pageHost = url?.let { Uri.parse(it).host }?.lowercase()
                progress.progress = 0
                progress.visibility = View.VISIBLE
                injectPageScripts(view)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                progress.visibility = View.GONE
                injectPageScripts(view)
                pageLoaded = true
                ui.removeCallbacks(targetTimeout)
                if (loadingSaved) {
                    loadingSaved = false
                    ui.removeCallbacks(savedTimeout)
                }
                contentReady = true
                tryHideSplash()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (!request.isForMainFrame) return
                ui.removeCallbacks(targetTimeout)
                if (loadingSaved) expireSavedLink() else showError(error.description.toString())
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                if (!request.isForMainFrame) return
                val code = errorResponse.statusCode
                if (loadingSaved && code >= 400) {
                    expireSavedLink()
                } else if (code == 404 || code == 410) {
                    // 403/5xx non vengono trattati come errore: i siti con protezioni anti-bot li usano per le loro pagine
                    ui.removeCallbacks(targetTimeout)
                    showError("HTTP $code")
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) = showFullscreen(view, callback)

            override fun onHideCustomView() = hideFullscreen()

            // Nuove finestre: MAI create (restituisce sempre false).
            // Un link target="_blank" verso lo stesso sito viene aperto nella stessa WebView;
            // tutto il resto (window.open, domini esterni) è un popup bloccato.
            // Con il Blocco Pubblicità disattivato anche i link _blank esterni si aprono nella stessa WebView.
            override fun onCreateWindow(
                view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message
            ): Boolean {
                val hit = view.hitTestResult
                val extra = if (hit != null && (hit.type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
                        hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)) hit.extra else null
                val host = extra?.let { Uri.parse(it).host }?.lowercase()
                val openHere = extra != null && (!AdBlocker.enabled ||
                    (host != null && AdBlocker.isSameSite(host, pageHost) && !AdBlocker.isAdHost(host)))
                if (openHere) view.loadUrl(extra!!) else AdBlocker.onPopupBlocked(extra ?: "window.open")
                return false
            }
        }
    }

    /** Element hiding anti-pubblicità e zoom video, a inizio e a fine pagina. */
    private fun injectPageScripts(view: WebView) {
        if (AdBlocker.enabled) {
            view.evaluateJavascript(AdBlocker.cosmeticScript(), null)
            view.evaluateJavascript(AdBlocker.HARDEN_SCRIPT, null)
        }
        if (zoom.mode() != 0) zoom.apply()
    }

    /** Applica la configurazione di DeviceConfig (valori automatici + override): User Agent, cursore, Blocco Pubblicità. */
    private fun applyConfig() {
        val cfg = DeviceConfig.resolve(this)
        val s = webView.settings
        s.userAgentString = DeviceConfig.userAgentString(this, cfg.userAgent)
        webView.setInitialScale(if (cfg.userAgent == DeviceConfig.UserAgent.TV) 100 else 0)
        cursorLayout.cursorEnabled = cfg.cursor
        AdBlocker.enabled = prefs.getBoolean(Prefs.KEY_ADBLOCK, true)
    }

    private fun clearBrowsingData() {
        webView.clearCache(true)
        webView.clearHistory()
        WebStorage.getInstance().deleteAllData()
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        prefs.edit().remove(Prefs.KEY_LAST_VISITED).apply()
        Toast.makeText(this, R.string.cache_cleared, Toast.LENGTH_SHORT).show()
        loadTarget()
    }

    // ---------------------------------------------------------------- fullscreen video

    private fun showFullscreen(view: View, callback: WebChromeClient.CustomViewCallback) {
        if (customView != null) {
            callback.onCustomViewHidden()
            return
        }
        val fix = DeviceConfig.resolve(this).videoFix
        if (fix) {
            // Fix Video TV: evita lo spostamento del video su Fire OS se la pagina era scrollata
            webView.scrollTo(0, 0)
            webView.evaluateJavascript("window.scrollTo(0, 0);", null)
        }
        customView = view
        customViewCallback = callback
        val params = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        if (fix) params.gravity = Gravity.CENTER
        fullscreenContainer.addView(view, params)
        fullscreenContainer.visibility = View.VISIBLE
        setGearVisible(false)
        cursorLayout.visibility = View.GONE
        if (fix) hideSystemBarsForVideo()
        zoom.burst(ui) { customView != null }
    }

    /** Azzera ogni stato legato al fullscreen e dice alla WebView che la vista video non esiste più. */
    private fun resetFullscreenState() {
        customViewCallback?.let { runCatching { it.onCustomViewHidden() } }
        customViewCallback = null
        customView = null
        fullscreenContainer.removeAllViews()
        fullscreenContainer.visibility = View.GONE
        webView.visibility = View.VISIBLE
        if (errorView.visibility != View.VISIBLE) cursorLayout.visibility = View.VISIBLE
        setGearVisible(true)
        enterImmersive()
    }

    /** Mette in pausa i video della pagina (evita che l'audio continui in background). */
    private fun pauseVideos() {
        webView.evaluateJavascript(
            "document.querySelectorAll('video').forEach(function(v){try{v.pause();}catch(e){}});", null
        )
    }

    private fun hideFullscreen() {
        val v = customView ?: return
        lastFullscreenExitAt = SystemClock.uptimeMillis()
        fullscreenContainer.removeView(v)
        fullscreenContainer.visibility = View.GONE
        cursorLayout.visibility = View.VISIBLE
        setGearVisible(true)
        customViewCallback?.onCustomViewHidden()
        customView = null
        customViewCallback = null
        enterImmersive()
    }

    /**
     * Nasconde status bar e navigation bar durante il video (WindowInsetsControllerCompat), ma solo se sono visibili:
     * l'app è già a schermo intero e un secondo cambio di insets ridimensiona la finestra mentre il video parte.
     */
    private fun hideSystemBarsForVideo() {
        val insets = ViewCompat.getRootWindowInsets(window.decorView)
        val barsVisible = insets?.isVisible(WindowInsetsCompat.Type.systemBars()) ?: false
        if (!barsVisible) return
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    // ---------------------------------------------------------------- ingranaggio (auto-hide)

    /** Fade-out dell'ingranaggio in fullscreen o scrollando in basso; fade-in uscendo dal fullscreen o scrollando in alto. */
    private fun setGearVisible(visible: Boolean) {
        if (gearVisible == visible) return
        gearVisible = visible
        if (visible) {
            btnSettings.visibility = View.VISIBLE
            btnSettings.animate().alpha(GEAR_ALPHA).setDuration(220).start()
        } else {
            btnSettings.animate().alpha(0f).setDuration(260)
                .withEndAction { if (!gearVisible) btnSettings.visibility = View.INVISIBLE }
                .start()
        }
    }

    private fun onPageScrolled(top: Int, delta: Int) {
        if (customView != null) return
        if (top < 40 || delta < -6) setGearVisible(true)
        else if (delta > 6 && top > 80) setGearVisible(false)
    }

    // ---------------------------------------------------------------- impostazioni

    private fun openSettings() {
        // Evita il doppio avvio (doppio click / click simulato dal cursore)
        val now = SystemClock.uptimeMillis()
        if (now - lastSettingsOpen < 800) return
        lastSettingsOpen = now
        try {
            startActivity(Intent(this, SettingsActivity::class.java))
        } catch (e: Exception) {
            Log.e("S41t4m4_Crash", "Errore apertura impostazioni", e)
            Toast.makeText(this, R.string.settings_error, Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------- tasti

    /** Tasto Menu del telecomando: alterna Adatta <-> Riempi. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // Su smartphone la vista fullscreen della WebView gestisce il Back da sola già alla pressione: quando arriva il
        // rilascio, customView è già null e onBackPressed() chiederebbe di premere ancora per uscire. Se la pressione
        // è iniziata in fullscreen, il rilascio viene consumato qui (e il fullscreen si chiude se è ancora aperto).
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                backStartedInFullscreen = customView != null
            } else if (event.action == KeyEvent.ACTION_UP && backStartedInFullscreen) {
                backStartedInFullscreen = false
                if (customView != null) hideFullscreen()
                return true
            }
        }
        if (event.keyCode == KeyEvent.KEYCODE_MENU) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) toggleZoom()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun toggleZoom() {
        val next = zoom.toggle()
        zoom.probeVideo { hasVideo ->
            val msg = if (hasVideo) {
                getString(R.string.zoom_label, getString(if (next == 1) R.string.zoom_fill else R.string.zoom_fit))
            } else {
                getString(R.string.zoom_no_video)
            }
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    /** Back: esce dal fullscreen, poi indietro nella cronologia, poi doppia pressione per uscire. */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Il Back che ha appena chiuso il fullscreen (anche per mano della WebView) non conta come richiesta di uscita
        if (SystemClock.uptimeMillis() - lastFullscreenExitAt < FULLSCREEN_BACK_GUARD_MS) return
        when {
            customView != null -> hideFullscreen()
            errorView.visibility != View.VISIBLE && webView.canGoBack() -> {
                pauseVideos()
                webView.goBack()
            }
            else -> {
                val now = SystemClock.uptimeMillis()
                if (now - lastBackAt < BACK_EXIT_WINDOW_MS) {
                    finish()
                } else {
                    lastBackAt = now
                    Toast.makeText(this, R.string.back_again_to_exit, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // ---------------------------------------------------------------- schermo intero

    @Suppress("DEPRECATION")
    private fun enterImmersive() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }
}
