package com.s41t4m4.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Impostazioni a schermo intero, per categorie (GENERALE / VIDEO / RETE / MANUTENZIONE), ognuna con titolo e
 * descrizione. Tutti i controlli sono focalizzabili col D-Pad e mostrano un bordo giallo quando hanno il focus.
 */
class SettingsActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val prefs by lazy { Prefs.get(this) }
    private val http by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    private val accent by lazy { ContextCompat.getColor(this, R.color.accent) }
    private val textColor by lazy { ContextCompat.getColor(this, R.color.text_primary) }
    private val dim by lazy { ContextCompat.getColor(this, R.color.text_dim) }

    private lateinit var etUrl: EditText
    private lateinit var etReload: EditText
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Qualsiasi errore nella costruzione della schermata non deve far crashare l'app
        try {
            buildUi()
        } catch (e: Exception) {
            Log.e("S41t4m4_Crash", "Errore creazione impostazioni", e)
            Toast.makeText(this, R.string.settings_error, Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- costruzione della UI

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(32))
        }

        root.addView(TextView(this).apply {
            text = getString(R.string.settings_title)
            setTextColor(textColor)
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
        }, row(0))

        val cfg = DeviceConfig.resolve(this)
        val isTv = cfg.profile == DeviceConfig.Profile.TV
        val optAuto = getString(R.string.opt_auto)
        val optOn = getString(R.string.opt_on)
        val optOff = getString(R.string.opt_off)
        val autoFlag = if (isTv) optOn else optOff

        // ---- GENERALE ----
        root.category(R.string.cat_general)

        root.itemTitle(R.string.set_url_title)
        root.itemDesc(R.string.set_url_desc)
        etUrl = EditText(this).apply {
            setText(Prefs.targetUrl(prefs) ?: "")
            hint = getString(R.string.url_hint)
            setTextColor(textColor)
            setHintTextColor(dim)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        styleControl(etUrl)
        root.addView(etUrl, row(0))

        root.itemTitle(R.string.set_reload_title)
        root.itemDesc(R.string.set_reload_desc)
        etReload = EditText(this).apply {
            setText(prefs.getInt(Prefs.KEY_RELOAD_MIN, 0).toString())
            setTextColor(textColor)
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine()
        }
        styleControl(etReload)
        root.addView(etReload, row(0))

        btnSave = newButton(getString(R.string.save_verify)) { saveAndVerify() }
        root.addView(btnSave, row(10))

        root.switchRow(R.string.set_resume_title, R.string.set_resume_desc, Prefs.KEY_RESUME, true, false)
        root.choiceRow(
            R.string.set_cursor_title, R.string.set_cursor_desc, Prefs.KEY_CURSOR,
            listOf(optAuto, optOn, optOff), autoFlag, false
        )

        // ---- VIDEO ----
        root.category(R.string.cat_video)
        root.choiceRow(
            R.string.set_zoom_title, R.string.set_zoom_desc, Prefs.KEY_ZOOM,
            listOf(getString(R.string.zoom_fit), getString(R.string.zoom_fill)), null, false
        )
        root.choiceRow(
            R.string.set_videofix_title, R.string.set_videofix_desc, Prefs.KEY_VIDEO_FIX,
            listOf(optAuto, optOn, optOff), autoFlag, false
        )

        // ---- RETE ----
        root.category(R.string.cat_network)
        root.switchRow(R.string.set_adblock_title, R.string.set_adblock_desc, Prefs.KEY_ADBLOCK, true, true)
        root.choiceRow(
            R.string.set_ua_title, R.string.set_ua_desc, Prefs.KEY_UA_MODE,
            listOf(
                optAuto, getString(R.string.opt_ua_tv),
                getString(R.string.opt_ua_mobile), getString(R.string.opt_ua_desktop)
            ),
            if (isTv) getString(R.string.opt_ua_tv) else getString(R.string.opt_ua_mobile), true
        )
        root.itemTitle(R.string.set_lists_title)
        root.itemDesc(R.string.set_lists_desc)
        root.addView(newButton(getString(R.string.update_lists)) { updateLists() }, row(0))

        // ---- MANUTENZIONE ----
        root.category(R.string.cat_maintenance)
        root.itemTitle(R.string.set_cache_title)
        root.itemDesc(R.string.set_cache_desc)
        root.addView(newButton(getString(R.string.btn_clear)) { confirmClear() }, row(0))
        root.itemTitle(R.string.set_info_title)
        root.itemDesc(R.string.set_info_desc)
        root.addView(newButton(getString(R.string.btn_info)) { showInfo() }, row(0))

        root.addView(newButton(getString(R.string.close)) { finish() }, row(32))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(ContextCompat.getColor(this@SettingsActivity, R.color.brand_bg))
            isFillViewport = true
            addView(root)
        })
        etUrl.requestFocus()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun row(topDp: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(topDp) }

    /** Sfondo con bordo giallo quando il controllo ha il focus (D-Pad). */
    private fun styleControl(v: View) {
        v.setBackgroundResource(R.drawable.bg_focusable)
        v.setPadding(dp(14), dp(10), dp(14), dp(10))
    }

    private fun newButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(accent)
        minimumHeight = dp(52)
        stateListAnimator = null
        styleControl(this)
        setOnClickListener { onClick() }
    }

    private fun LinearLayout.category(titleRes: Int) {
        addView(TextView(this@SettingsActivity).apply {
            text = getString(titleRes)
            setTextColor(accent)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
        }, row(30))
    }

    private fun LinearLayout.itemTitle(titleRes: Int) {
        addView(TextView(this@SettingsActivity).apply {
            text = getString(titleRes)
            setTextColor(textColor)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        }, row(16))
    }

    private fun LinearLayout.itemDesc(descRes: Int) {
        addView(TextView(this@SettingsActivity).apply {
            text = getString(descRes)
            setTextColor(dim)
            textSize = 12f
            setPadding(0, dp(2), 0, dp(8))
        }, row(0))
    }

    /** Interruttore On/Off: titolo (testo dello Switch) e descrizione sotto. */
    private fun LinearLayout.switchRow(titleRes: Int, descRes: Int, key: String, def: Boolean, reload: Boolean) {
        val sw = Switch(this@SettingsActivity).apply {
            text = getString(titleRes)
            setTextColor(textColor)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, checked ->
                val e = prefs.edit().putBoolean(key, checked)
                if (reload) e.putBoolean(Prefs.KEY_RELOAD_REQ, true)
                e.apply()
            }
        }
        styleControl(sw)
        addView(sw, row(16))
        itemDesc(descRes)
    }

    /** Scelta a rotazione (Auto / ...). autoInfo: cosa significa "Auto" su questo dispositivo (null = nessuna voce Auto). */
    private fun LinearLayout.choiceRow(
        titleRes: Int, descRes: Int, key: String, names: List<String>, autoInfo: String?, reload: Boolean
    ) {
        itemTitle(titleRes)
        itemDesc(descRes)
        val b = newButton("") {}
        fun refresh() {
            val raw = prefs.getInt(key, 0)
            val i = if (raw in names.indices) raw else 0
            b.text = if (i == 0 && autoInfo != null) "${names[0]} ($autoInfo)" else names[i]
        }
        b.setOnClickListener {
            val raw = prefs.getInt(key, 0)
            val current = if (raw in names.indices) raw else 0
            val e = prefs.edit().putInt(key, (current + 1) % names.size)
            if (reload) e.putBoolean(Prefs.KEY_RELOAD_REQ, true)
            e.apply()
            refresh()
        }
        refresh()
        addView(b, row(0))
    }

    // ---------------------------------------------------------------- azioni

    private fun saveAndVerify() {
        val url = Prefs.normalizeUrl(etUrl.text.toString())
        if (url == null) {
            etUrl.error = getString(R.string.url_invalid)
            return
        }
        etUrl.setText(url)
        val minutes = etReload.text.toString().trim().ifEmpty { "0" }.toIntOrNull()
        if (minutes == null || minutes < 0 || minutes > 1440) {
            etReload.error = getString(R.string.minutes_invalid)
            return
        }
        btnSave.isEnabled = false
        Toast.makeText(this, R.string.verifying, Toast.LENGTH_SHORT).show()
        scope.launch {
            // Controllo con richiesta HEAD
            val code = withContext(Dispatchers.IO) {
                try {
                    http.newCall(Request.Builder().url(url).head().build()).execute().use { it.code }
                } catch (e: Exception) {
                    -1
                }
            }
            if (isFinishing) return@launch
            btnSave.isEnabled = true
            if (code in 200..399) {
                save(url, minutes)
            } else {
                val reason = if (code > 0) "HTTP $code" else getString(R.string.unreachable)
                AlertDialog.Builder(this@SettingsActivity, R.style.S41Dialog)
                    .setTitle(R.string.verify_failed_title)
                    .setMessage(getString(R.string.verify_failed_msg, reason))
                    .setPositiveButton(R.string.save_anyway) { _, _ -> save(url, minutes) }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            }
        }
    }

    /** Salva URL e ricarica automatica; la schermata principale ricarica subito la WebView al ritorno. */
    private fun save(url: String, minutes: Int) {
        val changed = url != Prefs.targetUrl(prefs)
        val e = prefs.edit()
            .putString(Prefs.KEY_TARGET, url)
            .putInt(Prefs.KEY_RELOAD_MIN, minutes)
            .putBoolean(Prefs.KEY_RELOAD_REQ, true)
        // Nuovo sito: l'ultima pagina visitata appartiene al sito precedente
        if (changed) e.remove(Prefs.KEY_LAST_VISITED).remove(Prefs.KEY_LAST_VISITED_TS)
        e.apply()
        Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun updateLists() {
        Toast.makeText(this, R.string.loading, Toast.LENGTH_SHORT).show()
        AdBlocker.updateNow(this) { ok ->
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                Toast.makeText(this, if (ok) R.string.lists_ok else R.string.lists_fail, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun confirmClear() {
        AlertDialog.Builder(this, R.style.S41Dialog)
            .setTitle(R.string.clear_confirm_title)
            .setMessage(R.string.clear_confirm_msg)
            .setPositiveButton(R.string.btn_clear) { _, _ ->
                // La cancellazione la esegue la schermata principale (ha la WebView) al ritorno
                prefs.edit().putBoolean(Prefs.KEY_CLEAR_REQ, true).apply()
                finish()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showInfo() {
        AlertDialog.Builder(this, R.style.S41Dialog)
            .setTitle(R.string.info_title)
            .setMessage(buildInfo())
            .setPositiveButton(R.string.close, null)
            .show()
    }

    private fun buildInfo(): String {
        return try {
            val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ITALY)
            fun date(ms: Long) = if (ms > 0) fmt.format(Date(ms)) else getString(R.string.never)
            fun yn(b: Boolean) = if (b) "sì" else "no"

            @Suppress("DEPRECATION")
            val pi = packageManager.getPackageInfo(packageName, 0)
            @Suppress("DEPRECATION")
            val version = "${pi.versionName} (${pi.versionCode})"
            val cfg = DeviceConfig.resolve(this)
            val crash = prefs.getString(Prefs.KEY_LAST_CRASH, null)

            buildString {
                appendLine("Versione: $version")
                appendLine("Dispositivo: ${Build.MODEL} (${cfg.profile})")
                appendLine("User Agent: ${cfg.userAgent}")
                appendLine("Cursore virtuale: ${yn(cfg.cursor)}")
                appendLine("Fix Video TV: ${yn(cfg.videoFix)}")
                appendLine("Zoom: ${if (Prefs.zoomMode(this@SettingsActivity) == 1) "Riempi" else "Adatta"}" +
                    " (script in tutti i frame: ${yn(prefs.getBoolean(Prefs.KEY_ZOOM_ALLFRAMES, false))})")
                appendLine("Blocco Pubblicità: ${if (prefs.getBoolean(Prefs.KEY_ADBLOCK, true)) "attivo" else "disattivo"}")
                appendLine("Richieste bloccate: ${AdBlocker.blockedCount()}")
                appendLine("Popup bloccati: ${AdBlocker.popupBlocked()}")
                appendLine("Domini in blocklist: ${AdBlocker.domainCount()}")
                appendLine("Liste aggiornate: ${date(AdBlocker.lastUpdateMs(this@SettingsActivity))}")
                appendLine("Ultima pagina visitata: ${date(prefs.getLong(Prefs.KEY_LAST_VISITED_TS, 0L))}")
                appendLine(prefs.getString(Prefs.KEY_LAST_VISITED, "-"))
                append("URL sito: ${Prefs.targetUrl(prefs) ?: "-"}")
                if (!crash.isNullOrBlank()) {
                    append("\n\nUltimo errore (${date(prefs.getLong(Prefs.KEY_LAST_CRASH_TS, 0L))}):\n")
                    append(crash.lines().take(4).joinToString("\n"))
                }
            }
        } catch (e: Exception) {
            Log.e("S41t4m4_Crash", "Errore info app", e)
            getString(R.string.settings_error)
        }
    }
}
