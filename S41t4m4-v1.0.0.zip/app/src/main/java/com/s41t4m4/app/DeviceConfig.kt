package com.s41t4m4.app

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.util.Log
import android.webkit.WebSettings

/**
 * Configurazione automatica per tipo di dispositivo (smart defaults).
 *
 *  - Fire TV / Android TV: User Agent TV, cursore virtuale attivo, Fix Video TV attivo.
 *  - Smartphone / tablet (touch): User Agent Mobile, cursore disattivo, Fix Video TV disattivo.
 *
 * Ogni voce ha nelle impostazioni la scelta Auto (= valori del profilo) oppure forzata:
 * resolve() combina gli override salvati con i default del profilo rilevato.
 */
object DeviceConfig {

    private const val TAG = "S41t4m4"

    enum class Profile { TV, MOBILE }
    enum class UserAgent { TV, MOBILE, DESKTOP }

    /** Configurazione effettiva (override dell'utente + default del profilo). */
    data class Resolved(
        val profile: Profile,
        val userAgent: UserAgent,
        val cursor: Boolean,
        val videoFix: Boolean
    )

    // UserAgent TV: volutamente SENZA "Mobile" e senza "; wv" / "Version/4.0":
    // "Mobile" fa servire il layout smartphone, "wv" fa riconoscere la WebView a certi player.
    private const val TV_USER_AGENT =
        "Mozilla/5.0 (Linux; Android 9; AFTMM Build/PS7233) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/119.0.6045.163 Safari/537.36"

    private const val DESKTOP_USER_AGENT =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/119.0.0.0 Safari/537.36"

    /** TV: modelli Fire TV ("AFT..."), Leanback, Fire TV, modalità televisione, nessun touchscreen. */
    fun detectProfile(ctx: Context): Profile {
        val pm = ctx.packageManager
        val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        val tv = Build.MODEL.contains("AFT") ||
            pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
            pm.hasSystemFeature("amazon.hardware.fire_tv") ||
            ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
        return if (tv) Profile.TV else Profile.MOBILE
    }

    /** Al primo avvio memorizza il profilo rilevato (le impostazioni "Auto" lo seguono). */
    fun ensureFirstRun(ctx: Context) {
        val p = Prefs.get(ctx)
        if (!p.contains(Prefs.KEY_PROFILE)) {
            val profile = detectProfile(ctx)
            p.edit().putString(Prefs.KEY_PROFILE, profile.name).apply()
            Log.i(TAG, "Primo avvio: dispositivo rilevato = $profile (${Build.MODEL})")
        }
    }

    fun resolve(ctx: Context): Resolved {
        val p = Prefs.get(ctx)
        val profile = detectProfile(ctx)
        val tv = profile == Profile.TV

        val ua = when (p.getInt(Prefs.KEY_UA_MODE, 0)) {
            1 -> UserAgent.TV
            2 -> UserAgent.MOBILE
            3 -> UserAgent.DESKTOP
            else -> if (tv) UserAgent.TV else UserAgent.MOBILE
        }

        fun flag(key: String): Boolean = when (p.getInt(key, 0)) {
            1 -> true
            2 -> false
            else -> tv
        }
        return Resolved(profile, ua, flag(Prefs.KEY_CURSOR), flag(Prefs.KEY_VIDEO_FIX))
    }

    /** Stringa User Agent da impostare sulla WebView. */
    fun userAgentString(ctx: Context, ua: UserAgent): String = when (ua) {
        UserAgent.TV -> TV_USER_AGENT
        UserAgent.DESKTOP -> DESKTOP_USER_AGENT
        UserAgent.MOBILE -> WebSettings.getDefaultUserAgent(ctx)
    }
}
