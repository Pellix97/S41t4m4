package com.s41t4m4.app

import android.content.Context
import android.net.Uri
import android.util.Log
import android.webkit.WebResourceResponse
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Blocco pubblicità nativo (Opzione B, senza librerie esterne):
 *  0. whitelist assets/ad_whitelist.txt (CDN/player video) e video mai bloccati;
 *  1. lista offline in assets/ad_hosts.txt (~275 domini);
 *  2. liste scaricate (EasyList, AdGuard Base, Peter Lowe) ridotte ai soli domini
 *     e salvate in cache, aggiornate ogni 7 giorni;
 *  3. element hiding via CSS/JS iniettato nelle pagine;
 *  4. contatore richieste bloccate + log Logcat (tag "S41t4m4Ads").
 */
object AdBlocker {

    private const val TAG = "S41t4m4Ads"
    private const val MAX_AGE_MS = 7L * 24 * 60 * 60 * 1000
    private const val CACHE_HOSTS = "ad_hosts_cache.txt"
    private const val CACHE_COSMETIC = "ad_cosmetic_cache.txt"
    private const val MAX_SELECTORS = 1500

    // Sorgenti pubbliche: se una non risponde viene saltata
    private val SOURCES = listOf(
        "https://easylist.to/easylist/easylist.txt",
        "https://filters.adtidy.org/extension/ublock/filters/2_without_easylist.txt",
        "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0&mimetype=plaintext"
    )

    private val PATH_PATTERNS = listOf("/pagead/", "/adserver/", "/adframe", "/popunder", "/popads")

    private val DEFAULT_SELECTORS = listOf(
        "ins.adsbygoogle", "[id^=\"google_ads\"]", "[id^=\"div-gpt-ad\"]", ".adsbygoogle",
        "iframe[src*=\"doubleclick\"]", "iframe[src*=\"googlesyndication\"]",
        "[data-ad-slot]", "[data-google-query-id]", ".ad-container", ".ad-banner",
        ".ad-wrapper", ".advert", ".advertisement", "#ad-container", ".ad-slot",
        ".popup-overlay", "#popup-overlay", ".ad-overlay", ".ads-overlay", ".popup-ad",
        ".sticky-ad", ".floating-ad", ".sponsored", "div[class*=\"popunder\"]", "div[id*=\"popunder\"]"
    )

    /** Elementi rimossi dal DOM (non solo nascosti) da HARDEN_SCRIPT. */
    private val REMOVE_SELECTORS = listOf(
        "div.ad-container", "div.popup-overlay", "div.sponsored", "div#popup-overlay",
        "div.ad-overlay", "div.ads-overlay", "div.popup-ad", "div.sticky-ad", "div.floating-ad",
        "div[id^=\"google_ads\"]", "div[id^=\"div-gpt-ad\"]", "ins.adsbygoogle", "div.adsbygoogle",
        "iframe[src*=\"doubleclick\"]", "iframe[src*=\"googlesyndication\"]",
        "div[class*=\"popunder\"]", "div[id*=\"popunder\"]"
    )

    /**
     * Script iniettato in onPageStarted/onPageFinished:
     *  - window.open() restituisce sempre null (ulteriore barriera contro i popup);
     *  - rimuove dal DOM overlay e banner tipici (ad-container, popup-overlay, sponsored...);
     *  - nasconde i contenitori vuoti dei banner rimossi;
     *  - MutationObserver per ripetere la pulizia sugli elementi inseriti dopo.
     */
    val HARDEN_SCRIPT: String =
        "(function(){try{" +
        "try{window.open=function(){return null;};}catch(e){}" +
        "if(window.__h1)return;" +
        "var SEL=" + JSONArray(REMOVE_SELECTORS).toString() + ".join(',');" +
        "var re=/(^|[-_ ])(ad|ads|advert|advertisement|banner|sponsor|sponsored)([-_ ]|\$)/i;" +
        "function clean(){try{" +
        "document.querySelectorAll(SEL).forEach(function(el){el.style.setProperty('display','none','important');el.remove();});" +
        "document.querySelectorAll('div,section,aside,ins').forEach(function(el){" +
        "if(el.children.length===0&&(el.textContent||'').trim()===''&&el.offsetHeight>0&&el.offsetHeight<400" +
        "&&re.test((el.className||'')+' '+(el.id||''))){el.style.display='none';}});" +
        "}catch(e){}}" +
        "var t=null;function sched(){if(t)return;t=setTimeout(function(){t=null;clean();},300);}" +
        "clean();" +
        "new MutationObserver(sched).observe(document.documentElement,{childList:true,subtree:true});" +
        "window.__h1=1;" +
        "}catch(e){}})();"

    // Estensioni/flussi video: non vengono bloccati (a meno che l'host sia nella lista curata offline)
    private val VIDEO_MARKERS = listOf(".m3u8", ".mpd", ".mp4", ".m4s", ".m4v", ".webm", ".mov", ".ts?", ".aac", ".mp3")

    private val NET_RULE = Regex("^\\|\\|([a-z0-9][a-z0-9.-]*\\.[a-z]{2,})\\^(?:\\$(.*))?$")
    private val DOMAIN = Regex("^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$")

    @Volatile private var hosts: Set<String> = emptySet()
    @Volatile private var offlineHosts: Set<String> = emptySet()
    @Volatile private var whitelist: Set<String> = emptySet()
    @Volatile private var cosmeticJs: String = ""
    @Volatile private var initialized = false

    /** Interruttore generale (impostazioni -> Blocco Pubblicità). */
    @Volatile var enabled: Boolean = true

    private val blocked = AtomicInteger(0)
    private val popups = AtomicInteger(0)
    private val updating = AtomicBoolean(false)

    fun init(ctx: Context) {
        if (initialized) return
        val app = ctx.applicationContext
        val offline = HashSet<String>()
        try {
            app.assets.open("ad_hosts.txt").bufferedReader().useLines { lines ->
                lines.forEach { l ->
                    val t = l.trim().lowercase()
                    if (t.isNotEmpty() && !t.startsWith("#")) offline.add(t)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "ad_hosts.txt non leggibile: $e")
        }
        offlineHosts = offline

        val wl = HashSet<String>()
        try {
            app.assets.open("ad_whitelist.txt").bufferedReader().useLines { lines ->
                lines.forEach { l ->
                    val t = l.trim().lowercase()
                    if (t.isNotEmpty() && !t.startsWith("#")) wl.add(t)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "ad_whitelist.txt non leggibile: $e")
        }
        whitelist = wl

        val all = HashSet<String>(offline)
        val cachedHosts = File(app.filesDir, CACHE_HOSTS)
        if (cachedHosts.exists()) {
            runCatching { cachedHosts.useLines { ls -> ls.forEach { if (it.isNotBlank()) all.add(it.trim()) } } }
        }
        hosts = all

        val sels = ArrayList<String>()
        val cachedCos = File(app.filesDir, CACHE_COSMETIC)
        if (cachedCos.exists()) {
            runCatching { cachedCos.useLines { ls -> ls.forEach { if (it.isNotBlank()) sels.add(it) } } }
        }
        rebuildCosmetic(sels)
        initialized = true
        Log.i(TAG, "Inizializzato: ${hosts.size} domini, ${sels.size} selettori cosmetici")
    }

    /**
     * True se la richiesta va bloccata (chiamata da shouldInterceptRequest).
     * Mai bloccati: navigazione principale, host first-party, host in whitelist, flussi video
     * (salvo host della lista curata offline, es. pubblicità VAST).
     */
    fun shouldBlock(uri: Uri, pageHost: String?, isMainFrame: Boolean): Boolean {
        if (!enabled || isMainFrame) return false
        val host = uri.host?.lowercase() ?: return false
        if (isSameSite(host, pageHost) || isWhitelisted(host)) return false
        if (isVideoUrl(uri) && !inSet(offlineHosts, host)) return false
        val hit = matchesHost(host) || matchesPath(uri)
        if (hit) {
            val n = blocked.incrementAndGet()
            Log.d(TAG, "Bloccata #$n: $host")
        }
        return hit
    }

    /**
     * Decide se bloccare una navigazione del frame principale (shouldOverrideUrlLoading):
     *  - verso un host pubblicitario noto;
     *  - verso un altro sito senza gesto dell'utente e senza redirect del server (tipico dei redirect pubblicitari JS).
     */
    fun shouldBlockNavigation(host: String?, pageHost: String?, hasGesture: Boolean, isRedirect: Boolean, pageLoaded: Boolean): Boolean {
        if (!enabled) return false
        val h = host?.lowercase() ?: return false
        if (isSameSite(h, pageHost) || isWhitelisted(h)) return false
        if (matchesHost(h)) {
            Log.d(TAG, "Navigazione bloccata #${blocked.incrementAndGet()}: $h (host pubblicitario)")
            return true
        }
        if (pageLoaded && !hasGesture && !isRedirect) {
            Log.d(TAG, "Navigazione bloccata #${blocked.incrementAndGet()}: $h (cross-site senza gesto)")
            return true
        }
        return false
    }

    fun isSameSite(host: String?, pageHost: String?): Boolean {
        if (host == null || pageHost == null) return false
        return host == pageHost || host.endsWith(".$pageHost") || pageHost.endsWith(".$host")
    }

    fun isWhitelisted(host: String): Boolean = inSet(whitelist, host)
    fun isAdHost(host: String?): Boolean = host != null && !isWhitelisted(host.lowercase()) && matchesHost(host.lowercase())

    private fun isVideoUrl(uri: Uri): Boolean {
        val u = uri.toString().lowercase()
        return VIDEO_MARKERS.any { u.contains(it) }
    }

    /** True se l'host o un suo dominio padre è nell'insieme. */
    private fun inSet(set: Set<String>, host: String): Boolean {
        var h = host
        while (true) {
            if (set.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
            if (!h.contains('.')) return false
        }
    }

    fun popupBlocked(): Int = popups.get()
    fun onPopupBlocked(what: String) {
        Log.d(TAG, "Popup bloccato #${popups.incrementAndGet()}: $what")
    }

    private fun matchesHost(host: String): Boolean = inSet(hosts, host)

    private fun matchesPath(uri: Uri): Boolean {
        val p = uri.path ?: return false
        return PATH_PATTERNS.any { p.contains(it) }
    }

    fun emptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    fun cosmeticScript(): String = cosmeticJs
    fun blockedCount(): Int = blocked.get()
    fun domainCount(): Int = hosts.size

    fun lastUpdateMs(ctx: Context): Long {
        val f = File(ctx.applicationContext.filesDir, CACHE_HOSTS)
        return if (f.exists()) f.lastModified() else 0L
    }

    // ---------- Aggiornamento liste ----------

    fun updateIfStale(ctx: Context) {
        val age = System.currentTimeMillis() - lastUpdateMs(ctx)
        if (age > MAX_AGE_MS) updateNow(ctx, null)
    }

    /** Scarica e fonde le liste in background. Il callback viene chiamato su un thread secondario. */
    fun updateNow(ctx: Context, callback: ((Boolean) -> Unit)?) {
        val app = ctx.applicationContext
        if (!updating.compareAndSet(false, true)) { callback?.invoke(false); return }
        Thread {
            var success = false
            try {
                val client = OkHttpClient.Builder()
                    .connectTimeout(10, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .build()
                val newHosts = HashSet<String>()
                val sels = LinkedHashSet<String>()
                var okCount = 0
                for (url in SOURCES) {
                    try {
                        val body = client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                            if (r.isSuccessful) r.body?.string() else null
                        }
                        if (body != null) {
                            parseList(body, newHosts, sels, url.contains("yoyo.org"))
                            okCount++
                        } else {
                            Log.w(TAG, "Sorgente non disponibile: $url")
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Sorgente fallita: $url ($e)")
                    }
                }
                if (okCount > 0) {
                    File(app.filesDir, CACHE_HOSTS).writeText(newHosts.joinToString("\n"))
                    File(app.filesDir, CACHE_COSMETIC).writeText(sels.joinToString("\n"))
                    val merged = HashSet<String>(offlineHosts)
                    merged.addAll(newHosts)
                    hosts = merged
                    rebuildCosmetic(sels)
                    success = true
                    Log.i(TAG, "Liste aggiornate: ${merged.size} domini, ${sels.size} selettori")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Aggiornamento fallito: $e")
            } finally {
                updating.set(false)
                callback?.invoke(success)
            }
        }.start()
    }

    /** Estrae da una lista in formato EasyList/hosts solo i domini (||dominio^) e i selettori cosmetici generici. */
    private fun parseList(text: String, outHosts: MutableSet<String>, outSels: MutableSet<String>, plainDomains: Boolean) {
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("!") || line.startsWith("[") || line.startsWith("#")) {
                if (!line.startsWith("##")) continue
            }
            when {
                line.startsWith("||") -> {
                    val m = NET_RULE.matchEntire(line.lowercase()) ?: continue
                    val opts = m.groupValues[2]
                    val bad = opts.contains("domain=") || opts.contains("~") || opts.contains("redirect") ||
                        opts.contains("csp") || opts.contains("removeparam") || opts.contains("badfilter") ||
                        opts.contains("denyallow")
                    if (!bad) outHosts.add(m.groupValues[1])
                }
                line.startsWith("##") -> {
                    if (outSels.size >= MAX_SELECTORS) continue
                    val sel = line.substring(2)
                    val ok = sel.length in 2..120 && !sel.contains(":-abp") && !sel.contains("+js(") &&
                        !sel.contains(":has-text") && !sel.contains(":xpath") && !sel.contains(":style(") &&
                        !sel.contains("{") && !sel.contains("\\") && !sel.contains("'")
                    if (ok) outSels.add(sel)
                }
                plainDomains -> {
                    val tok = line.split(Regex("\\s+")).last().lowercase()
                    if (DOMAIN.matches(tok)) outHosts.add(tok)
                }
            }
        }
    }

    private fun rebuildCosmetic(selectors: Collection<String>) {
        val all = LinkedHashSet<String>(DEFAULT_SELECTORS)
        all.addAll(selectors)
        val css = all.joinToString("\n") { "$it{display:none!important}" }
        cosmeticJs = "(function(){try{var id='__h1_hide';if(document.getElementById(id))return;" +
            "var s=document.createElement('style');s.id=id;s.textContent=" + JSONObject.quote(css) +
            ";(document.head||document.documentElement).appendChild(s);}catch(e){}})();"
    }
}
