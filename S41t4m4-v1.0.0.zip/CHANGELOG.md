# Changelog

## 1.0.0 (versionCode 1)
Prima versione.

**Sito a link diretto**
- Nessuna auto-indicizzazione: l'utente inserisce l'URL del sito. Rimossi il parsing della pagina indice (Jsoup), le chiamate di rete per trovarlo, le relative preferenze e i messaggi di errore/timeout.
- Primo avvio (nessun `target_url` salvato): dialog "Benvenuto in S41t4m4. Inserisci l'URL del sito che vuoi aprire." con campo URL navigabile col D-Pad, "Salva" ed "Esci".
- Validazione: `https://` aggiunto in automatico se manca lo schema; spazi, schemi diversi da http/https e indirizzi senza host sono rifiutati.
- Se il sito non carica (errore di rete, HTTP 404/410 o timeout di 30 s) compare la schermata di errore con "Riprova" e "Apri Impostazioni". Nessun fallback.
- Se l'ultima pagina visitata non carica entro 7 secondi, si riapre l'URL del sito.

**Impostazioni**
- "URL Sito Indice" sostituito da "URL Sito Web" ("Inserisci l'indirizzo del sito che vuoi aprire all'avvio.").
- Salvando un nuovo URL la WebView si ricarica subito e l'ultima pagina del sito precedente viene dimenticata.
- "Ricarica automatica" ricarica il sito ogni N minuti.
- Invariate: Riprendi dall'ultima pagina, Cursore virtuale, Zoom, Fix Video TV, Blocco Pubblicità, User Agent, liste, cache, Info App.

**Tema e icone**
- Palette Saitama: giallo `#FFD700` (primario), rosso `#E53935` (secondario), sfondo `#121212`.
- Icone launcher adaptive (sfondo giallo + Saitama) e tonde, banner TV 320x180, splash dal nuovo logo.
- Cursore virtuale giallo.

**Base**
- UI minimale con ingranaggio auto-hide, AdBlock nativo, fix video JavaScript (`video_fit.js`), cursore TV, `DeviceConfig` automatico per TV/smartphone, gestione dello zoom (tasto Menu).
- Fix del tasto Indietro in fullscreen: il Back che chiude il fullscreen non chiede di premere di nuovo per uscire; stato fullscreen azzerato all'avvio e in `onStop`; video in pausa prima di `goBack()`.

**Build**
- Package `com.s41t4m4.app`, workflow GitHub Actions con artefatto `s41t4m4-debug-apk`.
